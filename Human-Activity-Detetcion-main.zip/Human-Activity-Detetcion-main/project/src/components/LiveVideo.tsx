import React, { useState, useEffect } from 'react';

function LiveVideo() {
  const [isActive, setIsActive] = useState(false);
  const [videoSrc, setVideoSrc] = useState(null);
  const [actionData, setActionData] = useState([]);

  const startStreaming = () => {
    setIsActive(true);
    setVideoSrc('http://localhost:5001/live');
  };

  const stopStreaming = async () => {
    setIsActive(false);
    setVideoSrc(null);
    
    await fetch('http://localhost:5001/stop_live', {
      method: 'POST',
    });
  };

  useEffect(() => {
    if (isActive) {
      const fetchData = async () => {
        const response = await fetch('http://localhost:5001/get_data');
        const data = await response.json();
        setActionData(data);
      };

      const interval = setInterval(fetchData, 3000); // Fetch data every 3s

      return () => clearInterval(interval);
    }
  }, [isActive]);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Live Camera Integration</h1>

      <div className="bg-white rounded-lg shadow-lg p-4 mb-8">
        {isActive ? (
          <img src={videoSrc} alt="Live Stream" className="w-full rounded-lg" />
        ) : (
          <p className="text-gray-500 text-center">Click "Start" to begin streaming.</p>
        )}
      </div>

      <button
        onClick={isActive ? stopStreaming : startStreaming}
        className={`w-full px-4 py-2 rounded-md transition-colors ${
          isActive
            ? 'bg-red-600 hover:bg-red-700 text-white'
            : 'bg-blue-600 hover:bg-blue-700 text-white'
        }`}
      >
        {isActive ? 'Stop' : 'Start'}
      </button>

      {actionData.length > 0 && (
        <div className="mt-8">
          <h2 className="text-2xl font-semibold mb-4">Detected Actions</h2>
          <div className="bg-white p-6 rounded-lg shadow-lg">
            {actionData.map((action, index) => (
              <p key={index} className="text-lg mb-2">
                {action.Action}: {action.Count}
              </p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default LiveVideo;
