import React from 'react';
import { Link } from 'react-router-dom';
import { Upload, Camera } from 'lucide-react';

function Home() {
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold text-gray-900 mb-8">
        Welcome to Human Activity Detection
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <Link
          to="/image-video"
          className="flex flex-col items-center p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow"
        >
          <Upload className="h-16 w-16 text-blue-600 mb-4" />
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Image & Video Upload</h2>
          <p className="text-gray-600">Upload images or videos for activity detection</p>
        </Link>
        <Link
          to="/live-video"
          className="flex flex-col items-center p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow"
        >
          <Camera className="h-16 w-16 text-blue-600 mb-4" />
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Live Video Detection</h2>
          <p className="text-gray-600">Real-time activity detection using your camera</p>
        </Link>
      </div>
    </div>
  );
}

export default Home;