import React, { useState, useRef } from 'react';
import { Upload } from 'lucide-react';

function ImageVideo() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [detections, setDetections] = useState<any[]>([]);
  const [processedUrl, setProcessedUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    handleFile(droppedFile);
  };

  const handleFile = (selectedFile: File) => {
    if (selectedFile && (selectedFile.type.startsWith('image/') || selectedFile.type.startsWith('video/'))) {
      setFile(selectedFile);
      const url = URL.createObjectURL(selectedFile);
      setPreview(url);
    }
  };

  const handleSubmit = async () => {
    if (!file) return;
    
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("http://localhost:5000/detect", {
        method: "POST",
        body: formData,
      });
      
      const data = await response.json();
      if (data.error) {
        console.error("Error:", data.error);
      } else {
        setDetections(data.detections || []);
        setProcessedUrl(data.image_url || data.video_url || null);
      }
    } catch (error) {
      console.error("Upload failed:", error);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Image / Video Analysis</h1>
      
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-8"
      >
        <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <input
          type="file"
          ref={fileInputRef}
          onChange={(e) => e.target.files && handleFile(e.target.files[0])}
          accept="image/*,video/*"
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors mb-4"
        >
          Choose files to Upload
        </button>
        <p className="text-gray-500">or drag and drop them here</p>
      </div>

      {preview && (
        <div className="mb-8">
          {file?.type.startsWith('image/') ? (
            <img src={preview} alt="Preview" className="max-w-full rounded-lg shadow-lg" />
          ) : (
            <video src={preview} controls className="max-w-full rounded-lg shadow-lg" />
          )}
        </div>
      )}

      {preview && (
        <button
          onClick={handleSubmit}
          className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          Analyze
        </button>
      )}

      {processedUrl && (
        <div className="mt-8">
          <h2 className="text-2xl font-semibold mb-4">Processed Output</h2>
          {file?.type.startsWith('image/') ? (
            <img src={processedUrl} alt="Processed" className="max-w-full rounded-lg shadow-lg" />
          ) : (
            <video src={processedUrl} controls className="max-w-full rounded-lg shadow-lg" />
          )}
        </div>
      )}

      {detections.length > 0 && (
        <div className="mt-8">
          <h2 className="text-2xl font-semibold mb-4">Detections</h2>
          <div className="bg-white p-6 rounded-lg shadow-lg">
            {detections.map((detection, index) => (
              <p key={index} className="text-lg mb-2">
                {detection.activity}: ({detection.bounding_box.x1}, {detection.bounding_box.y1}) - ({detection.bounding_box.x2}, {detection.bounding_box.y2})
              </p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default ImageVideo;
