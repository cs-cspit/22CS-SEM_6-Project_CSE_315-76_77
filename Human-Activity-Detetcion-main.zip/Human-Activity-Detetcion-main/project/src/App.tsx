import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Brain, Camera, History, Upload } from 'lucide-react';
import Home from './components/Home';
import ImageVideo from './components/ImageVideo';
import LiveVideo from './components/LiveVideo';
import HistoryPage from './components/History';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <nav className="bg-white shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <Brain className="h-8 w-8 text-blue-600" />
                <Link to="/" className="ml-2 text-2xl font-bold text-gray-900">
                  Human Activity Detection
                </Link>
              </div>
              <div className="flex items-center space-x-4">
                <NavLink to="/" icon={<Brain className="h-5 w-5" />} text="Home" />
                <NavLink to="/image-video" icon={<Upload className="h-5 w-5" />} text="Image & Video" />
                <NavLink to="/live-video" icon={<Camera className="h-5 w-5" />} text="Live Video" />
                {/* <NavLink to="/history" icon={<History className="h-5 w-5" />} text="History" /> */}
              </div>
            </div>
          </div>
        </nav>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/image-video" element={<ImageVideo />} />
            <Route path="/live-video" element={<LiveVideo />} />
            {/* <Route path="/history" element={<HistoryPage />} /> */}
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function NavLink({ to, icon, text }: { to: string; icon: React.ReactNode; text: string }) {
  return (
    <Link
      to={to}
      className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 transition-colors"
    >
      {icon}
      <span className="ml-2">{text}</span>
    </Link>
  );
}

export default App;